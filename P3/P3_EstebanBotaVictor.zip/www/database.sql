/* Comandos para la ejecucion del fichero
 mysql -h 127.0.0.1 -P 3306 -u vestbot -p >>> sibw 
 use SIBW;
 source ruta de la base de datos */


/* Borramos las tablas en caso de estar ya creadas */
DROP TABLE IF EXISTS Imagenes;
DROP TABLE IF EXISTS Comentarios;
DROP TABLE IF EXISTS Enlaces;
DROP TABLE IF EXISTS Reparto;
DROP TABLE IF EXISTS Descripcion;
DROP TABLE IF EXISTS Productos;
DROP TABLE IF EXISTS PalabrasProhibidas;



/* Creamos las tablas */

/* Tabla de Evento */
CREATE TABLE Productos(
  id INT AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  foto_portada VARCHAR(100) NOT NULL,
  estudio VARCHAR(100),
  precio VARCHAR(50),   
  PRIMARY KEY(id)
);

/*Tabla con enlaces de cada producto*/
CREATE TABLE Enlaces(
  id INT AUTO_INCREMENT,
  enlace VARCHAR(100),
  descripcion1 TEXT NOT NULL,
  descripcion2 TEXT,
  producto INT NOT NULL,
  PRIMARY KEY(id),
  FOREIGN KEY(producto) REFERENCES Productos(id)
);


/* Tabla de Imagenes */
CREATE TABLE Imagenes(
  id INT AUTO_INCREMENT,
  ruta VARCHAR(100),
  producto INT NOT NULL,
  pie VARCHAR(50),
  PRIMARY KEY(id),
  FOREIGN KEY(producto) REFERENCES Productos(id)
);

/* Tabla de comentarios */
CREATE TABLE Comentarios(
  id INT AUTO_INCREMENT,
  producto INT NOT NULL,
  autor VARCHAR(100) NOT NULL,
  comentario VARCHAR(300),
  fecha DATETIME,
  PRIMARY KEY(id),
  FOREIGN KEY(producto) REFERENCES Productos(id)
);

/*Tabla del Reparto de cada anime*/
CREATE TABLE Reparto(
  id INT AUTO_INCREMENT,
  producto INT NOT NULL,
  personaje VARCHAR(100) NOT NULL,
  seiyuu VARCHAR(100),
  PRIMARY KEY(id),
  FOREIGN KEY(producto) REFERENCES Productos(id)
);

/*Tabla de descripcion de cada anime*/
CREATE TABLE Descripcion(
  id INT AUTO_INCREMENT,
  producto INT NOT NULL,
  texto TEXT NOT NULL,
  PRIMARY KEY(id),
  FOREIGN KEY(producto) REFERENCES Productos(id)
);

/* Tabla de palabras prohibidas */
CREATE TABLE PalabrasProhibidas(
  palabra VARCHAR(50),
  PRIMARY KEY(palabra)
);

/* Añadimos algunos elementos por defecto a cada tabla */

INSERT INTO PalabrasProhibidas(palabra) VALUES('culo');
INSERT INTO PalabrasProhibidas(palabra) VALUES('horrible');
INSERT INTO PalabrasProhibidas(palabra) VALUES('odiar');
INSERT INTO PalabrasProhibidas(palabra) VALUES('eliminar');
INSERT INTO PalabrasProhibidas(palabra) VALUES('succionar');
INSERT INTO PalabrasProhibidas(palabra) VALUES('cago');
INSERT INTO PalabrasProhibidas(palabra) VALUES('marron');

INSERT INTO Productos(nombre,foto_portada,estudio,precio) VALUES ('Given','./imgs/Given.jpg','Lerche', '3€');
INSERT INTO Productos(nombre,foto_portada,estudio,precio) VALUES ('Pichi Pichi Pitch','./imgs/mermaidmelody.jpg','Sony Pictures Television', '3€');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Zombieland Saga','./imgs/zombieland.jpg');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Haikyuu!!','./imgs/haikyuu.jpg');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Kimetsu no Yaiba','./imgs/kimetsu.jpg');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Pretty Cure','./imgs/prettycure.jpg');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Tate no Yuusha','./imgs/tatenoyuusha.png');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Violet Evergarden','./imgs/violet.jpg');
INSERT INTO Productos(nombre,foto_portada) VALUES ('Fairy Tail','./imgs/fairytail.jpg');


INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/Given.jpg', 1, 'Anime Given');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/mermaidmelody.jpg', 2, 'Anime Pichi Pichi Pitch');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/zombieland.jpg', 3, 'Anime Zombieland Saga');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/haikyuu.jpg', 4, 'Anime Haikyuu!!');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/kimetsu.jpg', 5, 'Anime Kimetsu no Yaiba');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/prettycure.jpg', 6, 'Anime Pretty Cure');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/tatenoyuusha.png', 7, 'Anime Tate no Yuusha');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/violet.jpg', 8, 'Anime Violet Evergarden');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/fairytail.jpg', 9, 'Anime Fairy Tail');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/given_protas.jpg', 1, 'Personajes Given');
INSERT INTO Imagenes(ruta, producto, pie) VALUES('./imgs/personajes_pichi.jpg', 2, 'Personajes Pichi Pichi');



INSERT INTO Enlaces(enlace,descripcion1,descripcion2,producto) VALUES ('https://given-anime.com','TVアニメ『ギヴン』公式サイト','- Sitio web oficial de Given', 1);
INSERT INTO Enlaces(enlace,descripcion1,descripcion2,producto) VALUES ('https://twitter.com/given_anime','TVアニメ ギヴン』公式サイト (@given_anime)','- Twitter Oficial (japonés)', 1);
INSERT INTO Enlaces(enlace,descripcion1,descripcion2,producto) VALUES ('https://es.wikipedia.org/wiki/Mermaid_Melody:_Pichi_Pichi_Pitch','Wikipedia Pichi Pichi Pitch', '', 2);

INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (1, 'Mafuyu Sato','Shougo Yano');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (1, 'Ritsuka Uenoyama','Yūma Uchida');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (1, 'Hiiragi Kashima','Fumiya Imai');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (1, 'Haruki Nakayama','Masatomo Nakazawa');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (1, 'Ugetsu Murata','Shintarō Asanuma');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (1, 'Akihiko Kaji','Takuya Eguchi');

INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Luchia Nanami','Sara Polo');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Hannon Hōshō','Elena Palacios');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Rina Tōin','Ana Richart');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Karen','Belén Rodríguez');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Noel','Ana Plaza');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Coco','Inés Blázquez');
INSERT INTO Reparto(producto,personaje,seiyuu) VALUES (2, 'Sara','Ana Isabel Hernando');



INSERT INTO Descripcion(producto,texto) VALUES (1, 'Given es un anime basado en el manga del mismo nombre. Trata la historia de un chico Ritsuka Uenoyama que en su descanso de clases
  se encuentra con Mafuyu Sato sujetando una guitarra con las cuerdas rotas.
  En el momento en que Uenoyama termina de arreglar la guitarra, Mafuyu se queda prendado completamente de él. Sin embargo, escuchar la canción de Mafuyu por casualidad deja una profunda impresión en Uenoyama');
INSERT INTO Descripcion(producto,texto) VALUES (1, 'Tras esto, Uenoyama lo invita a formar parte de su banda junto a Haruki Nakayama y a Akihiko Kaji. Él acepta y a partir de aquí vemos como se va
                        desarrollando las relaciones entre estos personajes principalmente.');

INSERT INTO Descripcion(producto,texto) VALUES (2, 'La serie trata de las respectivas princesas sirenas de los 7 mares, contando sus aventuras por el mundo humano.

Luchia es la princesa sirena del Océano Pacífico Norte. Conocerá a Hanon, la princesa sirena del Océano Atlántico Sur, y a Rina, princesa del Océano Atlántico Norte.

Juntas se deberán enfrentar contra las diablesas acuáticas para devolver la paz al mar y a todos los que lo habitan.');

INSERT INTO Descripcion(producto,texto) VALUES (2, 'Más tarde conocerán a Karen, princesa del Océano Antártico. Las cuatro deben salvar a las tres princesas sirenas capturadas, Noel,
 hermana gemela de Karen, princesa del Océano Ártico, Coco, princesa del Océano Pacífico Sur, y Sarah, princesa del Océano Índico.');

INSERT INTO Descripcion(producto, texto) VALUES (3,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (3,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');

INSERT INTO Descripcion(producto, texto) VALUES (4,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (4,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');

INSERT INTO Descripcion(producto, texto) VALUES (5,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (5,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');

INSERT INTO Descripcion(producto, texto) VALUES (6,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (6,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');

INSERT INTO Descripcion(producto, texto) VALUES (7,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (7,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');

INSERT INTO Descripcion(producto, texto) VALUES (8,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (8,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');

INSERT INTO Descripcion(producto, texto) VALUES (9,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla maximus ultricies pharetra.
 Aenean velit ante, elementum nec hendrerit sit amet, lobortis auctor erat. 
 Praesent libero tortor, aliquam in mi ut, porttitor sagittis eros. In varius massa libero, vitae interdum tellus elementum id.
  Duis sagittis enim euismod, eleifend libero vitae, fermentum erat. Praesent libero nulla, mollis sit amet augue eu, sagittis eleifend felis. 
  Suspendisse viverra faucibus urna, a iaculis odio aliquam vitae. Sed tempor tincidunt nisi, in mollis dui blandit ut. Sed finibus a lorem vitae elementum. 
  Suspendisse ut leo erat. Proin eget sodales massa, a euismod mi. Vestibulum ornare lacinia sem tincidunt convallis. Nulla eget arcu ut turpis blandit semper. 
  Aliquam nec est sed est scelerisque gravida.');

INSERT INTO Descripcion(producto, texto) VALUES (9,'Donec vel sodales justo, sodales cursus velit. Sed tristique, mi eget facilisis ultricies, elit nisi varius sem, at finibus sapien elit nec elit. 
  Ut sagittis arcu nec ligula sollicitudin, non laoreet augue fringilla.
 Vivamus quis diam iaculis, faucibus metus in, venenatis purus. In sed cursus nunc. Ut nec porta dolor. Nulla elementum fermentum nunc sit amet fringilla.');


INSERT INTO Comentarios(producto, autor, comentario, fecha) VALUES(1, 'Mafuyu', 'Hi everyone!', NOW());
INSERT INTO Comentarios(producto, autor, comentario, fecha) VALUES(1, 'Uenoyama', 'Long time no see', NOW());
INSERT INTO Comentarios(producto, autor, comentario, fecha) VALUES(2, 'Luchia', 'Chicas! Kaito no me hace caso :(', NOW());
INSERT INTO Comentarios(producto, autor, comentario, fecha) VALUES(2, 'Hanon', 'Ay que pesada, siempre con lo mismo', NOW());

