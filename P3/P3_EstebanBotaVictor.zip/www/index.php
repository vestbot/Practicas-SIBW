<?php
	// Inicializamos el motor de plantillas
	require_once "/usr/local/lib/php/vendor/autoload.php";
    include("modelo.php");
	$loader = new \Twig\Loader\FilesystemLoader('template');
	$twig = new \Twig\Environment($loader);

	$database= database::getInstance();  //obtenemos una instancia de la base de datos para trabajar con ella.

    $lista_productos = $database->getListaProductos(); // sacamos una lista de todos los productos 

    echo $twig->render('index.html', ['lista_productos' => $lista_productos]);
?>