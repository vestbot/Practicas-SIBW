<?php

    //En este fichero incluyo todas las operaciones relacionadas con la base de datos
    class Database{
        private static $instance;
        private $mysqli;
    

        /* Constructor de la clase para crear el objeto mysqli */
        private function __construct(){
            $this->$mysqli = new mysqli("mysql", "vestbot", "sibw", "SIBW"); // creamos el objeto con el usuario que nos conectaremos
            if ($mysqli->connect_errno) { 
            echo ("Fallo al conectar: " . $mysqli->connect_error); //mensaje de error
            }

            $this->$mysqli->set_charset("utf8"); //Establece el conjunto de caracteres al que estamos usando
        }

        /* Obtener instancia de la base de datos para no hacer 50 conexiones */
        public static function getInstance(){
            if(!self::$instance instanceof self){ // si no tenemos creada una instancia, la creamos
                self::$instance = new self();
            }
        
            return self::$instance;
        }

        /* Funcion para obtener un producto por su identificador 
           Devuelve un array con: id, nombre, estudio, precio, descripcion, cast, enlaces */
        public function getProducto($idProd){
            $consulta = "SELECT * FROM Productos WHERE id=?"; // cogemos el producto con el id correspondiente
            /* cl representa una consulta lista */
            $cl = $this->$mysqli->prepare($consulta);
            $cl->bind_param("i",$idProd);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $producto = array('id' => '-1', 'nombre' => 'No tenemos un anime llamado asi :(', 'estudio' => 'XXX', 'precio' => 'YYY', 'descripcion' => 'ZZZ', 'cast' => 'VVV');
            
            if ($res->num_rows > 0) {
                $row = $res->fetch_assoc();
                
                $producto = array('id' => $row['id'], 'nombre' => $row['nombre'], 'estudio' => $row['estudio'], 'precio' => $row['precio'], 'descripcion' => $row['descripcion'], 'cast' => $row['cast']);
            }
            
            return $producto;
        }

        /* Funcion para obtener las fotos de un producto
           Devuelve un array con imagenes cada una con: ruta donde se encuentra la imagen y pie */
        public function getFotosProducto($idProd){
            $consulta = "SELECT * FROM Imagenes WHERE producto=?";
            /* cl representa una consulta lista */
            $cl = $this->$mysqli->prepare($consulta);
            $cl->bind_param("i",$idProd);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $imagen = array('ruta' => '../imgs/Given.jpg', 'pie' => 'Pie de foto');

            $lista_imagenes = array();
            
            while($row=$res->fetch_assoc()){  // añadimos en un array todas las imagenes que hay por cada producto
                $imagen = array('ruta' => $row['ruta'], 'pie' => $row['pie']);
                $lista_imagenes[] = $imagen;
            }
            
            return $lista_imagenes;
        }

        /* Funcion para obtener los enlaces de un producto
           Devuelve un array con enlaces cada uno con: enlace a la página , dos descripciones*/
        public function getEnlacesProducto($idProd){
            $consulta = "SELECT * FROM Enlaces WHERE producto=?";
            //cl representa una consulta lista 
            $cl = $this->$mysqli->prepare($consulta);
            $cl->bind_param("i",$idProd);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $enlace = array('enlace' => 'https://www.google.com/', 'descripcion1' => 'Google' , 'descripcion2' => 'xxx');

            $lista_enlaces = array();
            
            while($row=$res->fetch_assoc()){  // añadimos en un array todas las imagenes que hay por cada producto
                $enlace = array('enlace' => $row['enlace'], 'descripcion1' => $row['descripcion1'], 'descripcion2' => $row['descripcion2']);
                $lista_enlaces[] = $enlace;
            }
            
            return $lista_enlaces;
        }

        /* Funcion para obtener el cast de un anime
           Devuelve un array con el personaje y seiyuu asociados al anime*/
        public function getRepartoProducto($idProd){
            $consulta = "SELECT * FROM Reparto WHERE producto=?";
            //cl representa una consulta lista 
            $cl = $this->$mysqli->prepare($consulta);
            $cl->bind_param("i",$idProd);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $reparto = array('personaje' => 'Micky Mouse', 'seiyuu' => 'servidor' );

            $lista_reparto = array();
            
            while($row=$res->fetch_assoc()){  
                $reparto = array('personaje' => $row['personaje'], 'seiyuu' => $row['seiyuu']);
                $lista_reparto[] = $reparto;
            }
            
            return $lista_reparto;
        }

        /* Funcion para obtener la descripcion de un anime
           Devuelve un array con los parrafos de descripcion asociados al anime*/
        public function getDescripcionProducto($idProd){
            $consulta = "SELECT * FROM Descripcion WHERE producto=?";
            //cl representa una consulta lista 
            $cl = $this->$mysqli->prepare($consulta);
            $cl->bind_param("i",$idProd);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $parrafo = array('texto' => 'XXX' );

            $descripcion = array();
            
            while($row=$res->fetch_assoc()){  
                $parrafo = array('texto' => $row['texto']);
                $descripcion[] = $parrafo;
            }
            
            return $descripcion;
        }

        /* Funcion para obtener los comentarios de un evento 
           Devuelve un array con comentarios cada uno con: autor, comentario, fecha */
        public function getComentariosProducto($idProd){
            $consulta = "SELECT * FROM Comentarios WHERE producto=?";
            /* cl representa una consulta lista */
            $cl = $this->$mysqli->prepare($consulta);
            $cl->bind_param("i",$idProd);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $comentario = array('autor' => 'Anonimo', 'comentario' => 'me encanta este anime', 'fecha' => 'nunca');

            $lista_comentarios = array();
            
            while($row=$res->fetch_assoc()){
                $comentario = array('autor' => $row['autor'], 'comentario' => $row['comentario'], 'fecha' => $row['fecha']);
                $lista_comentarios[] = $comentario;
            }
            
            return $lista_comentarios;
        }

        /* Funcion para obtener la lista de productos 
           Devuelve un array con eventos cada uno con: id, nombre, foto_portada */
        public function getListaProductos(){
            $consulta = "SELECT id, nombre, foto_portada FROM Productos";
            /* cl representa una consulta lista */
            $cl = $this->$mysqli->prepare($consulta);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $producto = array('id' => '-1', 'nombre' => 'Producto', 'foto_portada' => '');

            $lista_productos = array();
            
            /* Para cada producto obtenido obtengo sus fotos y pongo la primera en la portada */
            while($row=$res->fetch_assoc()){
                $producto = array('id' => $row['id'], 'nombre' => $row['nombre'], 'foto_portada' => $row['foto_portada']);  
                $lista_productos[] = $producto;
            }
            
            return $lista_productos;
        }

        /* Funcion para obtener las palabras prohibidas
           Devuelve un array con de palabras */
        public function getPalabrasProhibidas(){
            $consulta = "SELECT * FROM PalabrasProhibidas";
            /* cl representa una consulta lista */
            $cl = $this->$mysqli->prepare($consulta);
            $cl->execute();
            $res=$cl->get_result();
            $cl->close();
        
            $palabra = array('palabra' => 'xxx');

            $lista_palabras = array();
            
            while($row=$res->fetch_assoc()){
                $palabra = array('palabra' => $row['palabra']);
                $lista_palabras[] = $palabra;
            }
            
            return $lista_palabras;
        }
    }

   



?>