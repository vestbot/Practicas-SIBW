<?php
$hash = password_hash('ganadora', PASSWORD_DEFAULT);
echo ($hash);
?>
